/*
  STORE SETTINGS — edit these values before publishing.
  Keep this file public-safe. NEVER put secret API keys or passwords here.
*/
window.STORE_CONFIG = {
  brandName: "Rahman Home",
  // International format without +, e.g. India's country code 91 + 10-digit number.
  whatsappNumber: "91XXXXXXXXXX",
  // Your own UPI ID, e.g. yourname@bank. Leave blank until configured.
  upiId: "",
  upiPayeeName: "Rahman Home",
  currency: "INR",
  products: [
    {
      id: "kitchen-organiser",
      name: "Everyday Kitchen Organiser",
      category: "Kitchen",
      price: 399,
      tag: "EVERYDAY EDIT",
      description: "A practical organiser to help keep everyday kitchen essentials in place.",
      image: "",
      supplierCost: null
    },
    {
      id: "drawer-organiser",
      name: "Drawer & Cutlery Organiser",
      category: "Storage",
      price: 299,
      tag: "SMART STORAGE",
      description: "A simple storage solution for tidier drawers and easier routines.",
      image: "",
      supplierCost: null
    },
    {
      id: "pantry-bins",
      name: "Pantry Storage Set",
      category: "Kitchen",
      price: 499,
      tag: "HOME FAVOURITE",
      description: "Bring a more considered look to pantry shelves and dry-goods storage.",
      image: "",
      supplierCost: null
    },
    {
      id: "sink-caddy",
      name: "Sink-side Utility Caddy",
      category: "Home",
      price: 249,
      tag: "SMALL SPACE",
      description: "Keep washing-up essentials together near the sink.",
      image: "",
      supplierCost: null
    },
    {
      id: "fridge-bins",
      name: "Fridge Storage Bins",
      category: "Storage",
      price: 449,
      tag: "ORGANISE BETTER",
      description: "A straightforward way to group items and make fridge shelves easier to use.",
      image: "",
      supplierCost: null
    },
    {
      id: "countertop-rack",
      name: "Countertop Storage Rack",
      category: "Kitchen",
      price: 599,
      tag: "SPACE SAVER",
      description: "Create a little more order around frequently used kitchen items.",
      image: "",
      supplierCost: null
    }
  ]
};
