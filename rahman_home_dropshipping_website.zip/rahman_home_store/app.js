(() => {
  "use strict";
  const cfg = window.STORE_CONFIG || {};
  const $ = (s) => document.querySelector(s);
  const money = (n) => new Intl.NumberFormat("en-IN", {style:"currency",currency:"INR",maximumFractionDigits:0}).format(n);
  const products = Array.isArray(cfg.products) ? cfg.products : [];
  let cart = {};
  let category = "All";
  let search = "";
  let toastTimer;

  const productGrid = $("#productGrid");
  const cartDrawer = $("#cartDrawer");
  const overlay = $("#overlay");
  const checkoutModal = $("#checkoutModal");
  const cartItems = $("#cartItems");

  function safeText(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function showToast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
  }
  function productById(id) { return products.find(p => p.id === id); }
  function countItems() { return Object.values(cart).reduce((sum, qty) => sum + qty, 0); }
  function subtotal() {
    return Object.entries(cart).reduce((sum, [id, qty]) => {
      const p = productById(id); return sum + (p ? Number(p.price) * qty : 0);
    }, 0);
  }
  function renderProducts() {
    const filtered = products.filter(p => {
      const matchCat = category === "All" || p.category === category;
      const haystack = `${p.name} ${p.description} ${p.category}`.toLowerCase();
      return matchCat && haystack.includes(search.toLowerCase());
    });
    productGrid.innerHTML = filtered.map(p => {
      const visual = p.image
        ? `<img src="${safeText(p.image)}" alt="${safeText(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.classList.remove('hidden')"><span class="product-fallback hidden">RH</span>`
        : `<span class="product-fallback">RH</span>`;
      return `<article class="product-card">
        <div class="product-visual">${visual}<span class="product-tag">${safeText(p.tag || p.category || "HOME EDIT")}</span></div>
        <div class="product-info"><div class="product-top"><h3 class="product-name">${safeText(p.name)}</h3><span class="product-price">${money(Number(p.price)||0)}</span></div>
        <p class="product-desc">${safeText(p.description || "")}</p>
        <button class="add-button" data-add="${safeText(p.id)}"><span>Add to bag</span><span>＋</span></button></div>
      </article>`;
    }).join("");
    $("#emptyState").classList.toggle("hidden", filtered.length > 0);
  }
  function renderCart() {
    $("#cartCount").textContent = countItems();
    $("#drawerCount").textContent = `(${countItems()})`;
    $("#cartEmpty").classList.toggle("hidden", countItems() > 0);
    $("#cartSummary").classList.toggle("hidden", countItems() === 0);
    $("#cartSubtotal").textContent = money(subtotal());
    $("#checkoutSubtotal").textContent = money(subtotal());
    cartItems.innerHTML = Object.entries(cart).map(([id, qty]) => {
      const p = productById(id); if (!p) return "";
      return `<div class="cart-item"><div class="cart-thumb">RH</div><div><h3>${safeText(p.name)}</h3><p>${money(p.price)} each</p><div class="qty-controls"><button data-qty="${safeText(id)}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${qty}</span><button data-qty="${safeText(id)}" data-delta="1" aria-label="Increase quantity">+</button></div><button class="remove-item" data-remove="${safeText(id)}">Remove</button></div><strong>${money(p.price * qty)}</strong></div>`;
    }).join("");
  }
  function openCart() {
    cartDrawer.classList.add("open"); cartDrawer.setAttribute("aria-hidden","false");
    overlay.classList.remove("hidden"); document.body.style.overflow = "hidden";
  }
  function closeCart() {
    cartDrawer.classList.remove("open"); cartDrawer.setAttribute("aria-hidden","true");
    if (checkoutModal.classList.contains("hidden")) { overlay.classList.add("hidden"); document.body.style.overflow = ""; }
  }
  function openCheckout() {
    if (!countItems()) return showToast("Your bag is empty.");
    closeCart();
    checkoutModal.classList.remove("hidden"); document.body.style.overflow = "hidden";
    $("#checkoutSubtotal").textContent = money(subtotal());
  }
  function closeCheckout() {
    checkoutModal.classList.add("hidden"); overlay.classList.add("hidden"); document.body.style.overflow = "";
  }
  function whatsappUrl(message) {
    const number = String(cfg.whatsappNumber || "").replace(/\D/g,"");
    if (!number || number.includes("XXXXXXXXXX") || number.length < 10) {
      showToast("Store setup needed: add your WhatsApp number in config.js.");
      return null;
    }
    return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
  }
  function buildOrderMessage(formData, paymentChoice) {
    const lines = Object.entries(cart).map(([id, qty]) => {
      const p = productById(id); return p ? `• ${p.name} × ${qty} — ${money(p.price * qty)}` : "";
    }).filter(Boolean).join("\n");
    return `${cfg.brandName || "Rahman Home"} — NEW ORDER REQUEST\n\n${lines}\n\nItems subtotal: ${money(subtotal())}\nShipping: Please confirm before payment\n\nCustomer: ${formData.get("name")}\nPhone: ${formData.get("phone")}\nAddress: ${formData.get("address")}, ${formData.get("city")} — ${formData.get("pincode")}\nPreferred payment: ${paymentChoice === "upi" ? "UPI (confirm final amount first)" : "WhatsApp coordination"}\n\nPlease confirm stock, delivery fee, final amount and estimated delivery before fulfilment.`;
  }

  productGrid.addEventListener("click", e => {
    const btn = e.target.closest("[data-add]");
    if (!btn) return;
    const id = btn.dataset.add;
    cart[id] = (cart[id] || 0) + 1;
    renderCart(); showToast("Added to your bag.");
  });
  cartItems.addEventListener("click", e => {
    const qtyBtn = e.target.closest("[data-qty]");
    const removeBtn = e.target.closest("[data-remove]");
    if (qtyBtn) {
      const id = qtyBtn.dataset.qty;
      cart[id] = (cart[id] || 0) + Number(qtyBtn.dataset.delta);
      if (cart[id] <= 0) delete cart[id];
      renderCart();
    }
    if (removeBtn) { delete cart[removeBtn.dataset.remove]; renderCart(); }
  });
  $("#openCart").addEventListener("click", openCart);
  $("#closeCart").addEventListener("click", closeCart);
  $("#continueShopping").addEventListener("click", closeCart);
  overlay.addEventListener("click", () => { closeCart(); closeCheckout(); });
  $("#checkoutButton").addEventListener("click", openCheckout);
  $("#closeCheckout").addEventListener("click", closeCheckout);
  $("#searchInput").addEventListener("input", e => { search = e.target.value.trim(); renderProducts(); });
  $("#categoryPills").addEventListener("click", e => {
    const btn = e.target.closest("[data-category]"); if (!btn) return;
    category = btn.dataset.category;
    $("#categoryPills").querySelectorAll(".pill").forEach(p => p.classList.toggle("active", p === btn));
    renderProducts();
  });
  $("#checkoutForm").addEventListener("change", e => {
    if (e.target.name === "payment") {
      $("#paymentWarning").textContent = e.target.value === "upi"
        ? "UPI opens a payment app for the items subtotal only. Confirm stock, shipping and final total with the store first. This website cannot verify payment automatically."
        : "Do not pay until stock, shipping and the final amount are confirmed.";
    }
  });
  $("#checkoutForm").addEventListener("submit", e => {
    e.preventDefault();
    if (!countItems()) { closeCheckout(); return showToast("Your bag is empty."); }
    const form = new FormData(e.currentTarget);
    const choice = form.get("payment");
    const message = buildOrderMessage(form, choice);
    const wa = whatsappUrl(message);
    if (!wa) return;
    if (choice === "upi") {
      const upiId = String(cfg.upiId || "").trim();
      if (!upiId || upiId.includes("YOUR_UPI_ID")) {
        showToast("Add your UPI ID in config.js before enabling UPI checkout.");
        return;
      }
      // Static UPI intent only: no server-side verification or automatic reconciliation.
      const params = new URLSearchParams({
        pa: upiId,
        pn: cfg.upiPayeeName || cfg.brandName || "Store",
        am: subtotal().toFixed(2),
        cu: "INR",
        tn: `Order request ${new Date().toLocaleDateString("en-IN")}`
      });
      window.open(`upi://pay?${params.toString()}`, "_blank");
      setTimeout(() => window.open(wa, "_blank", "noopener"), 500);
      showToast("After payment, confirm with the store. Final shipping may change the amount.");
    } else {
      window.open(wa, "_blank", "noopener");
    }
  });
  $("#footerWhatsApp").addEventListener("click", e => {
    e.preventDefault();
    const url = whatsappUrl(`Hello ${cfg.brandName || "Rahman Home"}, I have a question about your products.`);
    if (url) window.open(url, "_blank", "noopener");
  });
  $("#year").textContent = new Date().getFullYear();
  renderProducts(); renderCart();
})();
